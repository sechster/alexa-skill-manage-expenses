const Alexa = require('alexa-sdk');
const moment = require("moment");
//ask expense manager to add new expense with category regular description shopping and amount eleven

const APP_ID = 'amzn1.ask.skill.554f7f97-69da-43f3-a5b5-095a3e3bd3d9';

const HELP_MESSAGE = 'Piss off';
const HELP_REPROMPT = 'Piss off';
const STOP_MESSAGE = 'Goodbye!';


function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}


exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.appId = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

const handlers = {
    'LaunchRequest': function () {
        this.emit('AddExpenseIntent');
    },
    'AddExpenseIntent': function () {
        let expenseService = require("./expenseService");

        let year = moment().year();
        let month = moment().month() + 1;
        let day = moment().date();
    
        let service = new expenseService();
    
        let self = this;

        service.insertExpense({ 
            year: year, 
            month: month, 
            day: day, 
            category: capitalizeFirstLetter(this.event.request.intent.slots.category.value), 
            description: capitalizeFirstLetter(this.event.request.intent.slots.description.value), 
            amount: this.event.request.intent.slots.amount.value })
        .then(function() { 
            self.emit(':responseReady');
            self.response.speak("Expense inserted") });

        //this.response.speak(speechOutput);
    },
    'AMAZON.HelpIntent': function () {
        const speechOutput = HELP_MESSAGE;
        const reprompt = HELP_REPROMPT;

        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
    'AMAZON.StopIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
};































// let moment = require("moment");

// function capitalizeFirstLetter(string) {
//     return string.charAt(0).toUpperCase() + string.slice(1);
// }

// exports.handler = (event, context, callback) => {

//     let expenseService = require("./expenseService");

//     let year = moment().year();
//     let month = moment().month() + 1;
//     let day = moment().date();

//     let service = new expenseService();

//     service.insertExpense({ 
//         year: year, 
//         month: month, 
//         day: day, 
//         category: capitalizeFirstLetter(event.request.intent.slots.category.value), 
//         description: capitalizeFirstLetter(event.request.intent.slots.description.value), 
//         amount: event.request.intent.slots.amount.value });

    

//     callback();

//     context.succeed();
// };


// //insertExpense({ day: 12, category: "Regular", description: "Test", amount: 100, year: 2018, month: 12 });