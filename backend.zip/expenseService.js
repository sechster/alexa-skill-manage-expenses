let googleApiHelper = require("./googleApiHelper");

module.exports = function expenseServiceModule() {

    function insertExpense(expense) {
        return googleApiHelper.getSpreadsheetId(expense.year)
            .then( function(fileId) { return { spreadsheetFileId: fileId, sheetName: ("0" + expense.month).substr(-2) }; })
            .then( function(metadata) { googleApiHelper.appendDataToSpreadsheet(metadata, expense); });
    }

    let publicAPI = {
        insertExpense: insertExpense
    }

    return publicAPI;
}